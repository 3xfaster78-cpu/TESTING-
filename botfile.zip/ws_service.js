const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const express = require("express");
const fs      = require("fs");
const path    = require("path");
const pino    = require("pino");

const app  = express();
const PORT = 3000;
app.use(express.json());

// ── Storage ──────────────────────────────────────────────────────────────────
const SESSIONS_DIR = path.join(__dirname, "ws_sessions");
const OTP_FILE     = path.join(__dirname, "ws_otps.json");
const STOCK_FILE   = path.join(__dirname, "ws_stock.json");

if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR);

function loadJson(file, def = {}) {
    try { return JSON.parse(fs.readFileSync(file, "utf8")); }
    catch { return def; }
}
function saveJson(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// otps[phone]  = { code, ts }
// stock[phone] = { phone, password, price, btn_name, session_dir }
let otps  = loadJson(OTP_FILE, {});
let stock = loadJson(STOCK_FILE, {});

// Active sockets — phone → socket
const sockets = {};

// ── Helper: save / load OTP ───────────────────────────────────────────────────
function saveOtp(phone, code) {
    otps[phone] = { code, ts: Date.now() };
    saveJson(OTP_FILE, otps);
}

function getOtp(phone, afterTs = 0) {
    const e = otps[phone];
    if (!e) return null;
    if (e.ts < afterTs) return null;
    return e.code;
}

function clearOtp(phone) {
    delete otps[phone];
    saveJson(OTP_FILE, otps);
}

// ── Connect a WhatsApp session ────────────────────────────────────────────────
async function connectWA(phone, sessionDir, onOtp, onReady, onFail) {
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version }          = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        auth:           state,
        logger:         pino({ level: "silent" }),
        printQRInTerminal: false,
        browser:        ["Chrome", "Chrome", "120.0.0"],
        syncFullHistory: false,
    });

    sockets[phone] = sock;

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr }) => {
        if (connection === "open") {
            console.log(`[WS] ${phone} connected`);
            if (onReady) onReady();
        }
        if (connection === "close") {
            const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
            if (code !== DisconnectReason.loggedOut) {
                console.log(`[WS] ${phone} reconnecting...`);
                setTimeout(() => connectWA(phone, sessionDir, onOtp, onReady, onFail), 5000);
            } else {
                console.log(`[WS] ${phone} logged out`);
                delete sockets[phone];
                if (onFail) onFail("LOGGED_OUT");
            }
        }
    });

    // ── OTP capture from messages ──────────────────────────────────────────────
    sock.ev.on("messages.upsert", ({ messages, type }) => {
        if (type !== "notify") return;
        for (const msg of messages) {
            if (!msg.message) continue;
            const body =
                msg.message?.conversation ||
                msg.message?.extendedTextMessage?.text ||
                msg.message?.ephemeralMessage?.message?.extendedTextMessage?.text || "";

            // WhatsApp OTP pattern: "Your WhatsApp code: 123-456" or "123456"
            const m = body.match(/(\d{6})/);
            if (m) {
                const code = m[1];
                console.log(`[WS] OTP captured for ${phone}: ${code}`);
                saveOtp(phone, code);
                if (onOtp) onOtp(code);
            }
        }
    });

    return sock;
}

// ── Restore all stock sessions on boot ───────────────────────────────────────
async function restoreStockSessions() {
    for (const phone of Object.keys(stock)) {
        const sessionDir = path.join(SESSIONS_DIR, phone);
        if (!fs.existsSync(sessionDir)) continue;
        console.log(`[WS] Restoring session: ${phone}`);
        connectWA(phone, sessionDir, null, null, null);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  ADMIN ROUTES
// ════════════════════════════════════════════════════════════════════════════

// POST /admin/add   { phone, password, price, btn_name }
// Step 1 — initiate pairing (sends OTP to phone via WhatsApp itself)
app.post("/admin/add", async (req, res) => {
    const { phone, password, price, btn_name } = req.body;
    if (!phone || !price || !btn_name)
        return res.json({ ok: false, error: "phone, price, btn_name required" });

    if (stock[phone])
        return res.json({ ok: false, error: "ALREADY_EXISTS" });

    const sessionDir = path.join(SESSIONS_DIR, phone);
    if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });

    let responded = false;

    await connectWA(
        phone,
        sessionDir,
        null,
        () => {
            // Session already exists and connected — account ready
            if (!responded) {
                responded = true;
                stock[phone] = { phone, password: password || null, price: parseFloat(price), btn_name, session_dir: sessionDir };
                saveJson(STOCK_FILE, stock);
                res.json({ ok: true, status: "ALREADY_AUTHORIZED" });
            }
        },
        (err) => {
            if (!responded) { responded = true; res.json({ ok: false, error: err }); }
        }
    );

    // Give it 3 seconds to check if already authorized
    await new Promise(r => setTimeout(r, 3000));

    if (!responded) {
        responded = true;
        // Need OTP — tell Python bot to ask admin for OTP
        res.json({ ok: true, status: "OTP_REQUIRED", message: `OTP has been sent to ${phone} via WhatsApp. Send it back.` });
    }
});

// POST /admin/verify_otp   { phone, otp, password, price, btn_name }
app.post("/admin/verify_otp", async (req, res) => {
    const { phone, otp, password, price, btn_name } = req.body;
    if (!phone || !otp) return res.json({ ok: false, error: "phone and otp required" });

    const sock = sockets[phone];
    if (!sock) return res.json({ ok: false, error: "NO_SESSION — call /admin/add first" });

    try {
        // Use pairing code verification
        const result = await sock.requestPairingCode(phone);
        // For OTP-based login we rely on the session file being written by connectWA
        stock[phone] = {
            phone,
            password: password || null,
            price:    parseFloat(price || 0),
            btn_name: btn_name || phone,
            session_dir: path.join(SESSIONS_DIR, phone),
        };
        saveJson(STOCK_FILE, stock);
        res.json({ ok: true, status: "ACCOUNT_ADDED" });
    } catch (e) {
        res.json({ ok: false, error: e.message });
    }
});

// POST /admin/remove   { phone }
app.post("/admin/remove", async (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.json({ ok: false, error: "phone required" });

    const sock = sockets[phone];
    if (sock) {
        try { await sock.logout(); } catch {}
        delete sockets[phone];
    }

    delete stock[phone];
    saveJson(STOCK_FILE, stock);

    const sessionDir = path.join(SESSIONS_DIR, phone);
    if (fs.existsSync(sessionDir))
        fs.rmSync(sessionDir, { recursive: true, force: true });

    res.json({ ok: true });
});

// GET /admin/stock
app.get("/admin/stock", (req, res) => {
    res.json({ ok: true, stock });
});

// ════════════════════════════════════════════════════════════════════════════
//  BUYER ROUTES
// ════════════════════════════════════════════════════════════════════════════

// GET /buy/stock  — list available accounts for buyers
app.get("/buy/stock", (req, res) => {
    const available = {};
    for (const [phone, data] of Object.entries(stock)) {
        available[phone] = { btn_name: data.btn_name, price: data.price };
    }
    res.json({ ok: true, stock: available });
});

// POST /buy/get_number   { btn_name }
// Buyer selected an account — return the phone number
app.post("/buy/get_number", (req, res) => {
    const { btn_name } = req.body;
    const entry = Object.values(stock).find(s => s.btn_name === btn_name);
    if (!entry) return res.json({ ok: false, error: "NOT_FOUND" });
    res.json({ ok: true, phone: entry.phone, price: entry.price });
});

// POST /buy/get_otp   { phone, after_ts }
// Buyer sent OTP request to the number — bot polls for OTP
app.post("/buy/get_otp", (req, res) => {
    const { phone, after_ts = 0 } = req.body;
    const code = getOtp(phone, after_ts);
    if (!code) return res.json({ ok: false, status: "WAITING" });

    const entry = stock[phone];
    clearOtp(phone);

    // Remove from stock after delivery
    const password = entry?.password || null;
    delete stock[phone];
    saveJson(STOCK_FILE, stock);

    // Disconnect session
    const sock = sockets[phone];
    if (sock) {
        try { sock.end(); } catch {}
        delete sockets[phone];
    }

    res.json({ ok: true, code, password });
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, async () => {
    console.log(`[WS Service] Running on port ${PORT}`);
    await restoreStockSessions();
});
